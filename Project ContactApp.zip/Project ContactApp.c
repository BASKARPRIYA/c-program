#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <sys/stat.h>
#include <sys/types.h>
    char name[100];
    char num[50];
int create(){
    printf("\t*******************CREATE******************\n");
    printf("Enter the name: \n");
    scanf("%s",&name);
    printf("Enter the mobile number:\n");
    scanf("%s",&num);

    char username[50];
    printf("Enter the name to create a file: \n");
    scanf("%s",&username);

    char *nd;
    nd="contacts";
    mkdir(nd);

    char *newDirectory;
    newDirectory="C:\\Users\\priya\\Downloads\\contacts";
    chdir(newDirectory);

    char filename[50];
    sprintf(filename,"%s.txt",username);
    FILE *fc;
    fc=fopen(filename,"w");
    fprintf(fc," %s\n %s\n",name,num);
    fclose(fc);

    FILE *fc2;
    fc2=fopen("C:\\Users\\priya\\Downloads\\contacts\\allcontacts.txt","a");
    fprintf(fc,"Name:%s\nNumber:%s\n\n",name,num);
    fclose(fc2);

    printf("The contact created successfully\n\n");
    show();
}

int search(){
    printf("\t*******************SEARCH******************\n");
    char see[20];
    printf("Enter the contact file you want to search.\n");
    scanf("%s",&see);

    char *newDirectory;
    newDirectory="C:\\Users\\priya\\Downloads\\contacts";
    chdir(newDirectory);

    char filename[60];
    sprintf(filename,"%s.txt",see);
    char buff[255];
    FILE *fs;
    fs=fopen(filename,"r");
    while(fscanf(fs,"%s",buff)!=EOF){
          printf("%s\n",buff);
          }
    printf("\n");
    fclose(fs);
    show();
}

int display(){
    printf("\t*******************DISPLAY******************\n");
    char buff[255];
    FILE *fs;
    fs=fopen("C:\\Users\\priya\\Downloads\\contacts\\allcontacts.txt","r");
    while(fscanf(fs,"%s",buff)!=EOF){
       printf("%s\n",buff);
    }
    printf("\n");
    fclose(fs);
    show();
    }

int edit(){
    printf("\t*******************EDIT******************\n");
    char see[20];
    printf("Enter the contact file you want to edit.\n");
    scanf("%s",&see);

    char *newDirectory;
    newDirectory="C:\\Users\\priya\\Downloads\\contacts";
    chdir(newDirectory);

    char filename[60];
    sprintf(filename,"%s.txt",see);
    FILE *fs;
    fs=fopen(filename,"w");

    char name[100];
    char num[50];
    printf("Enter the name: \n");
    scanf("%s",&name);
    printf("Enter the mobile number:\n");
    scanf("%s",&num);

    fprintf(fs,"%s\n %s",name,num);
    fclose(fs);
    printf("Edited Succesfully!!\n\n");
    show();
    }

int del(){
    printf("\t*******************DELTE******************\n");
    char see[20];
    printf("Enter the contact file you want to delete.\n");
    scanf("%s",&see);

    char *newDirectory;
    newDirectory="C:\\Users\\priya\\Downloads\\contacts";
    chdir(newDirectory);

    char filename[100];
    sprintf(filename,"%s.txt",see);
    if (remove(filename)==0) {
        printf("File %s has been deleted successfully.\n\n", filename);
    }
    else{
        perror("Error deleting the file");
    }
    show();
    }

int out(){
    printf("ThankYou!!\n");
    }

int show(){
    int ip;
    printf("Do you want to continue the process:\n 1.Yes \n 2.No\n");
    scanf("%d",&ip);
    if(ip==1){
    int op;
    printf(" 1.Add new contact\n 2.Search Contact\n 3.Display Contact\n 4.Edit Contact\n 5.Delete Contact\n 6.Exit\n");
    printf("Enter the choice:\n");
    scanf("%d",&op);
    switch(op){
       case 1:
           create();
           break;
       case 2:
           search();
           break;
       case 3:
           display();
           break;
       case 4:
           edit();
           break;
       case 5:
           del();
           break;
       case 6:
           out();
    }
    }else{
    printf("Thanking You");
    }
}

int main(){
    printf("\t\t\t----------------------------------------------------------------------------------\n");
    printf("\t\t\t\t\t\tCONTACT APPLICATION\n");
    printf("\t\t\t----------------------------------------------------------------------------------\n");
    show();
}
